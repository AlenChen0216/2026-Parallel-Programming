#include <array>
#include <cstdio>
#include <cstdlib>
#include <thread>
#include "cycle_timer.h"

struct WorkerArgs
{
    float x0, x1;
    float y0, y1;
    unsigned int width;
    unsigned int height;
    int maxIterations;
    int *output;
    int threadId;
    int numThreads;
};

extern void mandelbrot_serial(float x0,
                              float y0,
                              float x1,
                              float y1,
                              int width,
                              int height,
                              int start_row,
                              int num_rows,
                              int max_iterations,
                              int *output);

extern void
write_ppm_image(int *data, int width, int height, const char *filename, int max_iterations);
//
// worker_thread_start --
//
// Thread entrypoint.
void worker_thread_start(WorkerArgs *const args)
{

    // TODO FOR PP STUDENTS: Implement the body of the worker
    // thread here. Each thread could make a call to mandelbrot_serial()
    // to compute a part of the output image. For example, in a
    // program that uses two threads, thread 0 could compute the top
    // half of the image and thread 1 could compute the bottom half.
    // Of course, you can copy mandelbrot_serial() to this file and
    // modify it to pursue a better performance.

    // printf("Hello world from thread %d\n", args->threadId);
    // int start_row, total_rows;
    // start_row = (args->height / args->numThreads) * args->threadId;
    // if (args->threadId == args->numThreads - 1){
    //     total_rows = args->height - start_row;
    // }else{
    //     total_rows = args->height / args->numThreads;
    // }
    // printf("thread %d: start_row = %d, total_rows = %d\n", args->threadId, start_row, total_rows);
    // int *tmp_output = new int[args->width * args->height];
    // double start_time = CycleTimer::current_seconds();
    int w = 4;
    static int next_row = 0;
    static int finished_workers = 0;
    const int height = static_cast<int>(args->height);
    while (true) {
        const int row = __atomic_fetch_add(&next_row, w, __ATOMIC_RELAXED);
        if (row >= height)
            break;
        const int rows_to_process = (w > height - row) ? height - row : w;
        mandelbrot_serial(args->x0, args->y0, args->x1, args->y1, args->width, args->height, row, rows_to_process, args->maxIterations, args->output);
    }
    // Calls to mandelbrot_thread are sequential; all workers join before the next call.
    if (__atomic_add_fetch(&finished_workers, 1, __ATOMIC_ACQ_REL) == args->numThreads) {
        __atomic_store_n(&next_row, 0, __ATOMIC_RELAXED);
        __atomic_store_n(&finished_workers, 0, __ATOMIC_RELAXED);
    }
    // double end_time = CycleTimer::current_seconds();
    // printf("thread %d finished in %.3f ms\n", args->threadId, (end_time - start_time) * 1000);

    // char filename[64];
    // snprintf(filename, sizeof(filename), "mandelbrot-thread-%d.ppm", args->threadId);
    // write_ppm_image(tmp_output, args->width, args->height, filename, args->maxIterations);

    // for(int j= start_row; j < start_row + total_rows; j++){
    //     for(int i=0; i < args->width; i++){
    //         args->output[j * args->width + i] = tmp_output[j * args->width + i];
    //     }
    // }
    // delete[] tmp_output;
}

//
// mandelbrot_thread --
//
// Multi-threaded implementation of mandelbrot set image generation.
// Threads of execution are created by spawning std::threads.
void mandelbrot_thread(int num_threads,
                       float x0,
                       float y0,
                       float x1,
                       float y1,
                       int width,
                       int height,
                       int max_iterations,
                       int *output)
{
    static constexpr int max_threads = 32;

    if (num_threads > max_threads)
    {
        fprintf(stderr, "Error: Max allowed threads is %d\n", max_threads);
        exit(1);
    }

    // Creates thread objects that do not yet represent a thread.
    std::array<std::thread, max_threads> workers;
    std::array<WorkerArgs, max_threads> args = {};

    for (int i = 0; i < num_threads; i++)
    {
        // TODO FOR PP STUDENTS: You may or may not wish to modify
        // the per-thread arguments here.  The code below copies the
        // same arguments for each thread
        args[i].x0 = x0;
        args[i].y0 = y0;
        args[i].x1 = x1;
        args[i].y1 = y1;
        args[i].width = width;
        args[i].height = height;
        args[i].maxIterations = max_iterations;
        args[i].numThreads = num_threads;
        args[i].output = output;

        args[i].threadId = i;
    }

    // Spawn the worker threads.  Note that only numThreads-1 std::threads
    // are created and the main application thread is used as a worker
    // as well.
    for (int i = 1; i < num_threads; i++)
    {
        workers[i] = std::thread(worker_thread_start, &args[i]);
    }

    worker_thread_start(&args[0]);

    // join worker threads
    for (int i = 1; i < num_threads; i++)
    {
        workers[i].join();
    }
}
